var token20=artifacts.require("token20");
module.exports=function(deployer)
{
    deployer.deploy(token20);
};